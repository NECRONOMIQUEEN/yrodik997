Themes
----------

Differences:

The 'indent' versions have track folder indentation. (tcp)
Both versions have their advantages and disadvantages.

Layouts are almost the same in all themes. So you can switch between themes
without problems.

Only the 'simple' versions have a 'freeze' layout. 

The themes use the new Reaper5 color stuff, but if you just disable/remove
the item background images and tweak some settings in the Prefs or in the reaper.ini file
you can use these themes also in Reaper4.

----------------

In the reaper.ini set alpha for selected/unselected items to:
selitem_tintalpha=0
unselitem_tintalpha=3

If you would like to have antialiazed waveforms, open the rtconfig file and change the 'peaksedges'
value from 1024 to 0. (can be found at the beginning of the rtconfig file...)

----------------

For Reaper4:

Disable/remove these images: item_bg.png ; item_bg_sel.png

----------------------------------------------------------------------------------------------------------------------

Install the font !!!
--------------------

HaxrCorp_S8.fon

It's quite important, because many things are designed around this font.
(Sorry, Windows only !)

----------------------------------------------------------------------------------------------------------------------

other useful settings
-----------------------

-In the Reaper Preferences-->Appearance-->Track control panels
 set meter minimum value to -60 and max value to 6 dB.
 It's important for the mcp layout 'Lightbulb'.

-mcp master track: right click on the meter
 display offset = 0 ; display gain = 0 ; red threshold = -18 (...type this in...)

-In your OS display settings change the scrollbar width to 17 pixels.
 Reaper's scrollbar needs this width/setting.

----------------------------------------------------------------------------------------------------------------------

toolbar_blank.png
---------------------

It's not in the ReaperThemeZip file.
Reason: If it's in the theme, it will override any toolbar icon which doesn't have the standard
30x30 pixel size (or icons with transparent backgrounds...).

Solution is to simply put it into the REAPER/Data/toolbar_icons folder.
If there's any pre-existing toolbar_blank icon (or composite_toolbar_overlay icon) in that folder, back-up them and remove them.

----------------------------------------------------------------------------------------------------------------------

default.reapalette
---------------------

This file has some predefined colors. Similar to the SWS colors (which is limited to 16 colors).
If you edit the reapalette file you have to restart Reaper. (colors are in RGB)
You can add as much colors as you want, i think. If you don't like my colors, make your own ones.
Put this file into the folder where the reaper.ini file is. (Action: Show REAPER resource path in explorer)
Put the Apollo.SWSColor file there too. (Action: SWS: Open color management window)

For now there are only 32 colors.
Create 32 macros with the 'SWS Cycle Actions' window (Action: Open/close Cycle Action editor),
put these macros into a toolbar and create some icons for them, fitting to these colors:

Color 01:
-Colors: Reset random color generator
-Track: Set to one random color

Color 02:
-Colors: Reset random color generator
--LOOP 2
-Track: Set to one random color
--ENDLOOP

Color 03:
-Colors: Reset random color generator
--LOOP 3
-Track: Set to one random color
--ENDLOOP

Color 04:
-Colors: Reset random color generator
--LOOP 4
-Track: Set to one random color
--ENDLOOP

...etc.

----------------------------------------------------------------------------------------------------------------------

Layouts
---------

Transport: With the action 'Show play position tempo and time signature' you can change the
                appearance of some of the mixer layouts (the ones which are marked with an asterisk).
                For the transport layout itself this action is not used.
                Also the action 'Center transport controls' is not used.

Track/Mixer Layout '------------------------': This is a 'separator' layout.
                                                              It has a name label which changes it's color
                                                              when the track is rec-armed (red) or is a folder parent track (yellow).

Track Layout 'Record': The record input label is also the record arm button.
                                 (Transparent record-arm button over recinput label...)

----------------------------------------------------------------------------------------------------------------------

Fonts
-------

To display things properly, you should use/have installed these fonts:

Volume/pan label font: Windows: HaxrCorp_S8 (Regular 9)
Track title font: Microsoft Sans Serif (Regular 8)
Walter font 1: Tahoma (Regular 8)
Walter font 7: Arial (Bold 12)
Walter font 8: Arial (Bold 20)


Timeline font: Microsoft Sans Serif (Regular 8)
Transport status font: Arial (Regular 22)
Media item label font: Microsoft Sans Serif (Regular 8)


If you are changing fonts in the theme editor you also might go to the rtconfig file
to make some changes there, too. (to change margins , walter font numbers, etc.)
When editing the margins, etc. in the rtconfig file, do this for every layout
(and of course for every Apollo-Version you are using !).

